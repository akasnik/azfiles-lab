# Description

The xDnsServerZoneTransfer DSC resource manages the replication settings of DNS Server zone data between servers.
